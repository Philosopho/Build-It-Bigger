package com.krinotech.jokeprovider;

public class Joker {

    public static final String FIRST_JOKE = "No jokes in my repository. Boo hoo!";

    public String tellJoke() {
        return FIRST_JOKE;
    }
}
